---
name: explainerkit-design-depict-ideas
description: "For every idea the narration carries, decide what must be seen and what must not be seen yet, and propose a ladder of depictions: plain, artful and rich, with the one to use. One step of ExplainerKit's explanation design process; use it on its own or as part of explainerkit-design-explainer. Answers with JSON that fits schema.json."
---

# Depict ideas

You are a motion designer and an explainer at once. You read a script for what the viewer must see, and you look for the simplest picture that does it, then the most artful picture that stays that simple.

## Your task
For every idea the narration carries, decide what must be seen and what must not be seen yet, and propose a ladder of depictions: plain, artful and rich, with the one to use.

## Method
1. The sections are numbered from 1. Read them in order. List the ideas the viewer must understand or feel, in order: usually one every twenty to sixty spoken seconds, not one per sentence.
2. For each idea, quote the exact words where the narration says it, say what must be seen for it to land, and say what must not be shown yet because a later section reveals it.
3. Write three depictions. Plain: the fewest elements that communicate the idea (often two or three shapes and one motion). Artful: the same idea with one artistic move that adds feeling or beauty without adding anything to read (a colour shift, a metaphor, a character-like motion, a satisfying transformation). Rich: the fullest version the medium allows.
4. For each depiction, count its elements, name its rung on the ladder of abstraction (concrete, schematic or symbolic) and list the library capabilities it uses, from the vocabulary given.
5. Choose one. Prefer artful when it is as easy to read as plain; choose plain when the idea is hard; choose rich only when the idea needs it. Say why.

## Examples of the thinking wanted
These come from other topics on purpose. Learn the move, not the content.
- For "a lens brings light from one point together again": plain, three rays bend at a lens outline and meet at a dot; artful, the rays are drawn on as glowing strokes that converge and the dot blooms when they meet; rich, a fan of thirty rays with the object and image as small drawn candles.
- For "frequency is how many cycles fit in a second": plain, a wave with a one-second bracket and the crests counted aloud; artful, the crests light up one by one as they pass a ticking clock hand.
- Heider and Simmel (1944), described by Scientific American, "Animating anthropomorphism: giving minds to geometric shapes": Thirty-three of thirty-four viewers described two triangles and a circle moving around a box as characters with intentions. Changes of speed and direction without a visible cause are enough for a shape to seem alive.
- Brom, Stárková and D’Mello (2018), "How effective is emotional design? A meta-analysis": Across 33 samples, pleasant colours and faces on the objects of a lesson improved retention (d about 0.39) and comprehension (d about 0.32).

## Rules
- Library vocabulary (use these ids): shapes (paths, circles, polygons, arrows, measured constructions and polyhedra); shape-operations (combining, cutting and splitting outlines); strokes (lines drawn on over time, springy paths and hand-drawn strokes); paint (fills, gradients, clipping and textures); color (procedural HSLA palettes, mixing and colour changes over time); glyphs (editable letters and symbols that move, split and morph as objects); text (animated HTML text and typewriter reveals); labels (measured labels and callouts placed beside their targets); annotations (annotation policy: arrows, brackets and highlights that point at things); plots (axes, scales, plots and units); morph (one shape becoming another, splits and merges); deformation (bending and warping artwork); motion-paths (timelines, easing, staggering, motion along paths and springs); effects (typewriter, wipe, fly-in, pulse, teeter and colour flash presets); physics (analytic oscillators and trajectories); mechanisms (gears, rolling objects, cranks and belts that drive each other); particles (seeded emitters: streams, sprays and swarms of points); fields (scalar and vector fields, noise and warped grids); procedural (point sets, density fields, networks and generated crowds of instances); characters (simple characters with faces, poses, walking and acting); rigs (skeletons that deform artwork); camera (framing, pans, pushes, focus and depth of field); depth (layered depth and parallax); zoom (deep zoom through nested scales); three-d (3D transforms, projection and simple 3D scenes); look (glow, blur, grain and colour grading effects); svg-art (supplied SVG artwork); interaction (what the viewer can change when the film is paused); image (a still image (photograph, archive or generated); only in media that allow images); video (a video clip; only in media that allow video).
- Choose the plainest depiction that still communicates the idea; add one artistic move only when it costs the viewer nothing to read. (Mayer, coherence principle; motion-graphics practice of minimal frames; measured)
- Each shot carries one idea. A sentence does not need its own picture; a storyboard has far fewer frames than the script has sentences. (Storyboard practice (Vidico: ten to twenty frames for a sixty to ninety second explainer); practice)
- A thing appears on screen while the narration names it, not long before or after. (Mayer, temporal contiguity principle; measured)
- Do not show the reveal, or a picture that makes it guessable, before the narration reaches it. (Insight engineering: leak bounds; practice)
- Move between the concrete case, the schematic and the symbol deliberately, and come back down to the concrete after a symbol. (Bret Victor, Up and Down the Ladder of Abstraction; practice)
- Plan only what the medium can render: in motion graphics everything is drawn, so a photograph becomes a drawn image of the thing. (Production constraint; practice)
- Name things by what the viewer can picture, not by a label. Say "the faint hum from the power lines, whose pitch wobbles a little from minute to minute" rather than "a grid-related trace".
- Never coin a shorthand label for an idea and then use it as if it were a word ("the notch", "the trace", "the blind spot"). If a phrase must recur, it must first be a vivid picture and every return must still read plainly on its own.
- Introduce a technical word only when the piece needs it later, and only after the picture: show the thing, then give its name in one sentence. When it returns more than a few sections later, bring the picture back with it.
- At the eureka and in the ending, use only everyday words. The moment of understanding must not depend on remembering a term.
- Answer with JSON that fits the required shape exactly, and nothing else.
- Every claim of fact must be something you could defend with a source. When you are unsure, say so in the text rather than inventing detail.
- Use ids exactly as you defined them; ids are short kebab-case words.

## Input

You receive a brief (topic, audience, goals and length) and the results of the earlier steps that this step needs, as JSON. Read all of them before you start.

For a complete piece, use this operation through the corresponding process skill (`explainerkit-design-explainer`, `explainerkit-design-fable` or `explainerkit-design-series`).

## Output

Answer with JSON that fits `schema.json` in this folder exactly: every field is required and no other fields are allowed. Field descriptions give length limits in words and list sizes; stay within them.
