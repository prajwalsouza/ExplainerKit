# ExplainerKit design skills

Agent Skills for Claude Code and Codex, exported from ExplainerKit's `explainerkit/design` module. Each folder is one skill: `SKILL.md` holds its instructions (the same text the library sends to a model), `schema.json` the shape of its answer, and `agents/openai.yaml` its Codex metadata.

Start with `explainerkit-design-explainer`, `explainerkit-design-fable` or `explainerkit-design-series`; they name the step skills to use at each stage.

Install by copying the folders into `~/.claude/skills/` for Claude Code or `~/.codex/skills/` for Codex.
