---
name: explainerkit-design-series
description: "Turn several subtopics or learning objectives into one stitched piece or a series, researching each as a full video, cutting what does not fit and bridging the chapters. Runs ExplainerKit's series design process step by step with its companion skills (explainerkit-design-*), keeping every intermediate result."
---

# Design a series or a long piece

Turn several subtopics or learning objectives into one stitched piece or a series, researching each as a full video, cutting what does not fit and bridging the chapters.

Work through the stages in order. Each step is its own skill: invoke it with the brief and the results of the earlier steps it needs, and keep its JSON answer, because later steps read it. Steps that the stages list as independent can run at the same time. The checks are plain rules; apply them yourself, or run the script in this folder where one is provided.

Use the stages below by default for a complete piece. If the brief needs a different approach, adapt the stages that need to change and follow the rest of the process wherever feasible. For example, when you plan a series backward from its finale, you can still research each chapter and pass those findings to the writer. Use supplied references as research inputs unless the brief limits the allowed sources. If you have to skip a stage, record which one, why and which later steps depend on its output.

## Stages

1. **Turn objectives into subtopics**: `$explainerkit-design-plan-subtopics`, only for learning objectives, then cover-objectives (a check: check that every learning objective is covered by at least one subtopic or chapter.), only for learning objectives.
2. **Research every subtopic as a full video** (once per subtopic): `$explainerkit-design-explore-wide`, then `$explainerkit-design-wander`, then `$explainerkit-design-propose-seeds`, then `$explainerkit-design-choose-seed`, then `$explainerkit-design-investigate`, then `$explainerkit-design-find-parallels`, then `$explainerkit-design-find-meaning`.
3. **Keep what fits, cut the rest**: cohesion-map (a check: measure how much the subtopics share: idea ids and content words in common, and which subtopics share nothing with the rest.), then `$explainerkit-design-assess-cohesion`.
4. **Order the chapters**: `$explainerkit-design-stitch`, then check-stitch (a check: check the stitched plan: objectives covered, cut material not used, every chapter handed off, time within budget.).
5. **Plan the hook and the chapter refills**: `$explainerkit-design-research-hooks`, then `$explainerkit-design-engineer-hooks`.
6. **Write every chapter** (once per chapter): `$explainerkit-design-develop-telling`, then `$explainerkit-design-draft-script`, then `$explainerkit-design-review-science`, then `$explainerkit-design-review-story`, then `$explainerkit-design-revise`, then `$explainerkit-design-polish-voice`, only when the voice gate finds problems.
7. **Bridge, measure and name it**: `$explainerkit-design-bridge-chapters`, then script-measures (a check: count words, rhythm, questions, address, numbers, hedges, instructions and stock phrases in the narration.), then `$explainerkit-design-name-it`, then check-cuts (a check: find cut people and stories that reappear in the written narration.).
8. **Keep the viewer watching, chapter by chapter**: `$explainerkit-design-audit-attention-part`, then attention-measures (a check: keep the viewer's patience ledger over spoken time: spending counted in the text, earning taken from the audit's quotes found in the text, the balance curve, its low points and droughts, the opening and every section's first seconds, and the questions left open.), then `$explainerkit-design-revise-for-attention`, only when the attention gate finds problems; kept only if it leaves fewer.
9. **Look up how others showed it**: `$explainerkit-design-research-visuals`.
10. **Decide what each idea must show**: `$explainerkit-design-depict-ideas`, then `$explainerkit-design-plan-shots`, then time-shots (a check: time every shot from its cue in the narration, and check order, coverage, length and the medium.).
11. **Plan the visual structure**: `$explainerkit-design-design-structure`, then structure-measures (a check: measure the visual structure: shot lengths and cut rate, runs of one framing, whether every shot is in one sequence, intensity contrast between sequences, intensity where attention is low and the central image at both ends.).
12. **Look, feeling, motion and sound**: independently of one another, `$explainerkit-design-design-look`; look-measures (a check: check the look: valid HSLA colours, palette size, text contrast, accent use and value contrast at the peaks.); `$explainerkit-design-design-emotion`; emotion-measures (a check: check the emotional design: moves that carry no idea, decoration early, untied humour, character and metaphor coverage and a reflective close.); `$explainerkit-design-design-motion`; motion-measures (a check: check the motion plan: too many movers at once, long static shots, incongruent motion and a subject whose screen direction flips.); `$explainerkit-design-design-sound`, only when the medium has music or effects; sound-measures (a check: check the sound plan: music too loud under dense shots, effects not tied to a motion, no space before the reveal, and cues the medium cannot play.), only when the medium has music or effects.
13. **Check against the multimedia principles** (repeat 2 times; each round's chosen question is the next round's focus): multimedia-measures (a check: check the shot plan against the narration: redundant or long on-screen text, labels not said in their shot, too many elements, decoration in the opening, protected moments without a signal, long unpaused stretches and names used before they are shown.), then `$explainerkit-design-audit-multimedia`, then `$explainerkit-design-replan-shots`, only for shots whose words changed in a kept narration edit.
14. **Storyboard, animatic, style frames and images**: `$explainerkit-design-write-image-prompts`, only when the medium allows images.

## Writing rules

- Talk like a person, not a narrator: react, have an opinion, admit what seemed strange to you, allow yourself a joke. Say "I" about once a minute, for a reaction, a confession or an opinion.
- Vary the rhythm: some sentences of three or four words, and in every section at least one long one (25 words or more) that carries the listener through a whole thought. Never three short sentences in a row.
- Tell and show; do not give orders. Instructions ("Put a lens over...") only when the viewer is genuinely doing something at home.
- Name real people, places, objects and numbers. Abstract nouns are a last resort.
- Never use stock narration: "Have you ever wondered", "In this video", "Let's dive in", "fascinating", "mind-blowing", "journey", "delve", "buckle up", "stay tuned", "tapestry".
- Name things by what the viewer can picture, not by a label. Say "the faint hum from the power lines, whose pitch wobbles a little from minute to minute" rather than "a grid-related trace".
- Never coin a shorthand label for an idea and then use it as if it were a word ("the notch", "the trace", "the blind spot"). If a phrase must recur, it must first be a vivid picture and every return must still read plainly on its own.
- Introduce a technical word only when the piece needs it later, and only after the picture: show the thing, then give its name in one sentence. When it returns more than a few sections later, bring the picture back with it.
- At the eureka and in the ending, use only everyday words. The moment of understanding must not depend on remembering a term.
- Say a qualification aloud only when, without it, the audience would leave believing something false. Put every other qualification, condition or production warning in the notes field.
- Keep spoken hedges (can, may, might, ideal, typically, under conditions...) to about two per hundred words.
- When the story needs a measurement, give the published number and its source in the notes; do not say that nobody has measured it.
- List in cites the ids of the research claims each section relies on. Do not paste URLs into the narration; sources travel with the claim ids.
- Never leave a placeholder for a result ("[report the actual result]"). If the piece shows an experiment, say what it shows, using a published result.

## The result

Write the final script as an outline: the narration itself, split into lines so each claim and source sits beneath the sentence it supports. Every line starts with a tag in square brackets and its children are indented two spaces beneath it:

- [section] the section's id
  - [narration] one paragraph of what is spoken (long, flowing, written for the ear)
  - [visual] what the audience sees
  - [note] caveats and production details, never read aloud
  - [claim] a research claim the section relies on (confidence)
    - [source] title — URL

