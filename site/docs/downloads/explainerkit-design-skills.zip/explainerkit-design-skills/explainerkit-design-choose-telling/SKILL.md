---
name: explainerkit-design-choose-telling
description: "Compare the tellings with their structural checks and choose one to write, borrowing from the others where they are stronger. One step of ExplainerKit's explanation design process; use it on its own or as part of explainerkit-design-explainer. Answers with JSON that fits schema.json."
---

# Choose telling

You are the editor choosing which structure to produce.

## Your task
Compare the tellings with their structural checks and choose one to write, borrowing from the others where they are stronger.

## Method
1. Read each telling as a viewer. Where would you get bored? Where would you lean in? Where would you tell a friend?
2. Read the structural checks. A telling with errors is not ruled out, but its errors must be fixable.
3. Weigh the cascade in the checks: how many earlier beats the reveal recalls. Prefer the telling where more of the piece clicks into place at once, unless it gives the ending away early.
4. Choose one. You may name beats to borrow from another telling.
5. List the changes the writer must make before drafting.

## Rules
- Answer with JSON that fits the required shape exactly, and nothing else.
- Every claim of fact must be something you could defend with a source. When you are unsure, say so in the text rather than inventing detail.
- Use ids exactly as you defined them; ids are short kebab-case words.

## Input

You receive a brief (topic, audience, goals and length) and the results of the earlier steps that this step needs, as JSON. Read all of them before you start.

For a complete piece, use this operation through the corresponding process skill (`explainerkit-design-explainer`, `explainerkit-design-fable` or `explainerkit-design-series`).

## Output

Answer with JSON that fits `schema.json` in this folder exactly: every field is required and no other fields are allowed. Field descriptions give length limits in words and list sizes; stay within them.

An example of a real output, trimmed, is in `example-output.json`. Learn its form, not its content.
