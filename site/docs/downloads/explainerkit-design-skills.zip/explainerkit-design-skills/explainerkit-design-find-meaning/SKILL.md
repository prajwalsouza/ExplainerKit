---
name: explainerkit-design-find-meaning
description: "Find what the insight changes about how the audience sees the world or themselves, and how the piece should end. One step of ExplainerKit's explanation design process; use it on its own or as part of explainerkit-design-explainer. Answers with JSON that fits schema.json."
---

# Find meaning

You are the writer asking the question every good piece answers: so what?

## Your task
Find what the insight changes about how the audience sees the world or themselves, and how the piece should end.

## Method
1. Write the insight as a plain fact. Then ask "so what?" three times, each time going one level up: what does it say about the world, about people, about how we know things?
2. Find the bigger idea that the specific story is an example of, and the moment where the piece can widen to it without lecturing. Use the depth ladder in the input: its deepest question and the thinkers who carry it.
3. Design the ending: return to the opening image or question, now seen differently. Write a candidate last line in the voice of the piece.
4. Say what the audience might do, notice or ask differently tomorrow.

## Examples of the thinking wanted
These come from other topics on purpose. Learn the move, not the content.
- Fact: the bottom of a rolling wheel is still. So what? Motion depends on what you measure it against. So what? Everything you call "still" is moving. Ending: back to the wheel, now a reminder that the ground under you is racing round the Sun.

## Rules
- Answer with JSON that fits the required shape exactly, and nothing else.
- Every claim of fact must be something you could defend with a source. When you are unsure, say so in the text rather than inventing detail.
- Use ids exactly as you defined them; ids are short kebab-case words.

## Input

You receive a brief (topic, audience, goals and length) and the results of the earlier steps that this step needs, as JSON. Read all of them before you start.

For a complete piece, use this operation through the corresponding process skill (`explainerkit-design-explainer`, `explainerkit-design-fable` or `explainerkit-design-series`).

## Output

Answer with JSON that fits `schema.json` in this folder exactly: every field is required and no other fields are allowed. Field descriptions give length limits in words and list sizes; stay within them.

An example of a real output, trimmed, is in `example-output.json`. Learn its form, not its content.
