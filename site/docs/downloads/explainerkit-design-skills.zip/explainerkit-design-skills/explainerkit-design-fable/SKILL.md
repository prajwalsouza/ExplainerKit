---
name: explainerkit-design-fable
description: "Turn a topic into a short story whose plot runs on the science, with an exact correspondence between story and mechanism and an afterword that names the real science. Runs ExplainerKit's fable design process step by step with its companion skills (explainerkit-design-*), keeping every intermediate result."
---

# Design a science fable

Turn a topic into a short story whose plot runs on the science, with an exact correspondence between story and mechanism and an afterword that names the real science.

Work through the stages in order. Each step is its own skill: invoke it with the brief and the results of the earlier steps it needs, and keep its JSON answer, because later steps read it. Steps that the stages list as independent can run at the same time. The checks are plain rules; apply them yourself, or run the script in this folder where one is provided.

Use the stages below by default for a complete piece. If the brief needs a different approach, adapt the stages that need to change and follow the rest of the process wherever feasible. For example, when you plan a series backward from its finale, you can still research each chapter and pass those findings to the writer. Use supplied references as research inputs unless the brief limits the allowed sources. If you have to skip a stage, record which one, why and which later steps depend on its output.

## Stages

1. **Explore and think laterally**: first pick-stimuli (a check: choose random words and far fields for lateral thinking, repeatably from a seed.); then independently of one another, `$explainerkit-design-explore-wide`; `$explainerkit-design-reframe`; `$explainerkit-design-provoke`; `$explainerkit-design-random-entry`; `$explainerkit-design-connect-distant`; `$explainerkit-design-create-frames`; `$explainerkit-design-wander`, once for each of a, b; then keep-wanderings (a check: merge several wanderings, drop near-duplicates by word overlap, and keep the most fun, diverse ones.).
2. **Choose a truth people misjudge**: `$explainerkit-design-propose-truths`, then rank-seeds (a check: order seeds by a weighted score that favours wonder and surprise, penalises textbook first examples, and keep the best few.), then `$explainerkit-design-choose-seed`.
3. **Research it**: `$explainerkit-design-investigate`.
4. **Try three allegories**: independently of one another, `$explainerkit-design-map-allegory`, once for each of kingdom, rules-of-magic, small-fable; then check-allegories (a check: check how many steps of the mechanism each allegory maps, by word overlap, and list the steps nobody mapped.); then `$explainerkit-design-choose-allegory`.
5. **Plot, write and measure**: `$explainerkit-design-plot-fable`, then `$explainerkit-design-write-fable`, then fable-measures (a check: count words, rhythm, dialogue lines, questions and stock phrases in the fable, and any of the real field's vocabulary that leaked onto the page.).
6. **Review the science and the craft**: independently of one another, `$explainerkit-design-review-allegory`; `$explainerkit-design-review-fable`.
7. **Revise and name it**: `$explainerkit-design-revise-fable`, then fable-measures (a check: count words, rhythm, dialogue lines, questions and stock phrases in the fable, and any of the real field's vocabulary that leaked onto the page.), then `$explainerkit-design-name-it`.

## Writing rules

- Talk like a person, not a narrator: react, have an opinion, admit what seemed strange to you, allow yourself a joke. Say "I" about once a minute, for a reaction, a confession or an opinion.
- Vary the rhythm: some sentences of three or four words, and in every section at least one long one (25 words or more) that carries the listener through a whole thought. Never three short sentences in a row.
- Tell and show; do not give orders. Instructions ("Put a lens over...") only when the viewer is genuinely doing something at home.
- Name real people, places, objects and numbers. Abstract nouns are a last resort.
- Never use stock narration: "Have you ever wondered", "In this video", "Let's dive in", "fascinating", "mind-blowing", "journey", "delve", "buckle up", "stay tuned", "tapestry".
- Name things by what the viewer can picture, not by a label. Say "the faint hum from the power lines, whose pitch wobbles a little from minute to minute" rather than "a grid-related trace".
- Never coin a shorthand label for an idea and then use it as if it were a word ("the notch", "the trace", "the blind spot"). If a phrase must recur, it must first be a vivid picture and every return must still read plainly on its own.
- Introduce a technical word only when the piece needs it later, and only after the picture: show the thing, then give its name in one sentence. When it returns more than a few sections later, bring the picture back with it.
- At the eureka and in the ending, use only everyday words. The moment of understanding must not depend on remembering a term.
- Say a qualification aloud only when, without it, the audience would leave believing something false. Put every other qualification, condition or production warning in the notes field.
- Keep spoken hedges (can, may, might, ideal, typically, under conditions...) to about two per hundred words.
- When the story needs a measurement, give the published number and its source in the notes; do not say that nobody has measured it.
- List in cites the ids of the research claims each section relies on. Do not paste URLs into the narration; sources travel with the claim ids.
- Never leave a placeholder for a result ("[report the actual result]"). If the piece shows an experiment, say what it shows, using a published result.

## The result

Write the final script as an outline: the narration itself, split into lines so each claim and source sits beneath the sentence it supports. Every line starts with a tag in square brackets and its children are indented two spaces beneath it:

- [section] the section's id
  - [narration] one paragraph of what is spoken (long, flowing, written for the ear)
  - [visual] what the audience sees
  - [note] caveats and production details, never read aloud
  - [claim] a research claim the section relies on (confidence)
    - [source] title — URL

