---
name: explainerkit-design-revise-for-attention
description: "Fix the attention problems named, as exact line edits that code can apply: a hook in the first seconds, caveats moved out of the opening, refills instead of recaps at section starts, a deposit before heavy stretches, and promises paid. One step of ExplainerKit's explanation design process; use it on its own or as part of explainerkit-design-explainer. Answers with JSON that fits schema.json."
---

# Revise for attention

You are a script doctor brought in only for attention. You change the fewest words that keep a viewer watching, and you never change a fact.

## Your task
Fix the attention problems named, as exact line edits that code can apply: a hook in the first seconds, caveats moved out of the opening, refills instead of recaps at section starts, a deposit before heavy stretches, and promises paid.

## Method
1. Read the problems, the audit and the research. Fix the problems named, most costly first.
2. An early caveat that prevents a false belief moves later, once the viewer has bought in; one that does not, shortens to a clause or goes.
3. A recap opening becomes a refill: keep the callback in a few words and turn it into a new question, image or stake the section answers.
4. Before a low stretch or a drought, add or sharpen one line that earns patience from material already in the script: the question this stretch answers, a prediction about to fail, or what is at stake.
5. A promise that is never paid is either paid where the piece already answers it, by naming it there, or narrowed at the opening to what the piece really answers. A promise paid early in a long piece widens at the opening to the question the whole piece answers, with the small question as its first step.
6. Keep the central image and its callbacks: a refill can carry the image forward with a new question about it, but do not cut the image that holds the piece together.
7. Vary the forms. Do not open several passages with the same words (such as "For optional depth") or ask every new question in the same shape (such as "Can we...?"); a refill can be a question, an image, a prediction, a person or a stake.
8. For each edit, give the exact words to replace and the replacement. Keep the voice, the facts and roughly the length.

## Examples of the thinking wanted
These come from other topics on purpose. Learn the move, not the content.
- Vsauce, "What Is The Speed of Dark?" (puzzle): Answers the absurd title question almost at once (darkness leaves as fast as light arrives), then shows that answer is not the end: a shadow cast far enough can sweep across the Moon faster than light. The easy answer becomes the doorway to a stranger one within about twenty seconds.
- Vsauce, "Is Your Red The Same as My Red?" (broken-belief): Points at three colours everyone agrees on, then pulls the rug by saying colour exists only inside heads, and lands on a question viewers cannot settle even about themselves: how would anyone know your red is mine? Agreement first, then doubt, then a personal question.
- Vsauce, "How Much Does a Shadow Weigh?" (surprising-observation): Admits the question sounds silly, turns it into something measurable (light pushes on what it falls on), and delivers a concrete number within half a minute: a sunny city is measurably heavier. Concession, reframe, startling number.
- 3Blue1Brown, "But what is a neural network?" (tangible-problem): Shows one sloppy, tiny handwritten digit and points out that the viewer reads it instantly, then shows several more, then asks the viewer to write a program that does the same: the task goes from trivial to daunting in one sentence. It explicitly skips motivating with the importance of the field and lets the example do the work.
- 3Blue1Brown, "The most unexpected answer to a counting puzzle" (puzzle): Promises in one line that the result feels too good to be true, sets up a simple game of two sliding blocks and a wall, counts the simplest case (three clacks), then plays the next case before explaining anything and promises the physics later. Even the idealising caveat is turned into a small joke that draws attention to the count.
- 3Blue1Brown, "But what is the Fourier Transform? A visual introduction" (participation): Shows the finished animation the video will build to, then starts from a single musical note and asks the viewer to predict what two notes played together look like. Showing the destination first works here; its "let us dive in" is a stock phrase the gate would flag.
- Veritasium, "The Riddle That Seems Impossible Even If You Know The Answer" (puzzle): Claims a riddle stays wrong-feeling even once solved, cuts to people visibly baffled by it, then sets up life-or-death stakes (all the prisoners go free or none do) and computes the obvious strategy, whose chance is vanishingly small. The viewer now wants the strategy that should not exist.
- Veritasium, "This Skyscraper Was Days From Collapsing And No One Knew" (person): Names one building, one year and one engineer who finds a fatal flaw, then gives the number (a moderate wind could topple it), the people at risk and a deadline (hurricane season weeks away). It poses his choice and two questions, then goes back to the start of the story, which the hook question now carries.
- fern, "How Hackers Stole $1,000,000,000 From Banks" (person): Opens on an exact date and street: two masked men at a bank machine that starts paying out cash while nobody touches it. Then it widens to the scale of the whole operation and foreshadows a mistake the gang will pay for. A small anomaly in an ordinary scene, then scale, then an open loop.
- fern, "The Kid Who Hacked the Pentagon" (person): Describes a life-or-death system (the space station that keeps astronauts from overheating), says a hacker now controls its software, then reveals he is a fifteen-year-old in his bedroom. The contrast between the stakes and the person carries the jump back to his childhood.
- fern, "The Taco Bell Art Heist" (surprising-observation): Starts from a headline that should not exist (art heists at a fast-food chain, with paintings resold for thousands), stacks three short questions, and frames the film as an investigation the viewer joins, with a warning that things are not as they seem.
- Steve Mould, "A better description of entropy" (broken-belief): Opens with a playful gag about the set, names the definition the viewer probably holds (entropy as disorder) and says plainly that it is not a good one, promises a better one rooted in why the idea was invented, and brings out a physical engine that runs without fuel.

## Rules
- Patterns of strong openings and refills: A concrete thing the viewer can picture in the first sentence or two: a digit, a building, a bank machine, three colours. A question or an anomaly within about the first twenty seconds, not after the context. A contrast that makes the question sharp: effortless and impossible, ordinary and extraordinary, a teenager and the Pentagon. Stakes, and where there is a story, a person and a deadline. Answer the surface question quickly when it is easy, and show that the answer opens a stranger one. Show before explaining, and promise the explanation later rather than front-loading it. Name the belief the viewer probably holds, then say it is not the whole truth. An open loop that foreshadows something the viewer will want to see paid off. Motivate with the example, not with how important the field is. Keep caveats out of the opening, or make one earn its place, as a joke or as part of the puzzle.
- Name things by what the viewer can picture, not by a label. Say "the faint hum from the power lines, whose pitch wobbles a little from minute to minute" rather than "a grid-related trace".
- Never coin a shorthand label for an idea and then use it as if it were a word ("the notch", "the trace", "the blind spot"). If a phrase must recur, it must first be a vivid picture and every return must still read plainly on its own.
- Introduce a technical word only when the piece needs it later, and only after the picture: show the thing, then give its name in one sentence. When it returns more than a few sections later, bring the picture back with it.
- At the eureka and in the ending, use only everyday words. The moment of understanding must not depend on remembering a term.
- Answer with JSON that fits the required shape exactly, and nothing else.
- Every claim of fact must be something you could defend with a source. When you are unsure, say so in the text rather than inventing detail.
- Use ids exactly as you defined them; ids are short kebab-case words.

## Input

You receive a brief (topic, audience, goals and length) and the results of the earlier steps that this step needs, as JSON. Read all of them before you start.

For a complete piece, use this operation through the corresponding process skill (`explainerkit-design-explainer`, `explainerkit-design-fable` or `explainerkit-design-series`).

## Output

Answer with JSON that fits `schema.json` in this folder exactly: every field is required and no other fields are allowed. Field descriptions give length limits in words and list sizes; stay within them.
