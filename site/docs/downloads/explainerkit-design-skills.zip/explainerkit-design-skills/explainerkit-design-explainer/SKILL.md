---
name: explainerkit-design-explainer
description: "Turn a topic into a researched, reviewed narration script with a story, a structure that builds to an insight, and its claims and sources. Runs ExplainerKit's explainer design process step by step with its companion skills (explainerkit-design-*), keeping every intermediate result."
---

# Design a narrated explainer

Turn a topic into a researched, reviewed narration script with a story, a structure that builds to an insight, and its claims and sources.

Work through the stages in order. Each step is its own skill: invoke it with the brief and the results of the earlier steps it needs, and keep its JSON answer, because later steps read it. Steps that the stages list as independent can run at the same time. The checks are plain rules; apply them yourself, or run the script in this folder where one is provided.

Use the stages below by default for a complete piece. If the brief needs a different approach, adapt the stages that need to change and follow the rest of the process wherever feasible. For example, when you plan a series backward from its finale, you can still research each chapter and pass those findings to the writer. Use supplied references as research inputs unless the brief limits the allowed sources. If you have to skip a stage, record which one, why and which later steps depend on its output.

## Stages

1. **Describe the audience at each level of mastery**: `$explainerkit-design-build-audience`.
2. **Reframe the topic in a loop, alongside exploring** (repeat 2 times; each round's chosen question is the next round's focus): pick-lenses (a check: choose lens families for a reframing round, repeatably from a seed, never repeating one already used in the loop.), then `$explainerkit-design-deepen-frame`, then fresh-frames (a check: drop frames whose questions share most of their words with questions from earlier rounds, keeping at least one.), then `$explainerkit-design-read-around`, then `$explainerkit-design-choose-depth`.
3. **Explore and think laterally**: first pick-stimuli (a check: choose random words and far fields for lateral thinking, repeatably from a seed.); then independently of one another, `$explainerkit-design-explore-wide`; `$explainerkit-design-explore-everyday`; `$explainerkit-design-reframe`; `$explainerkit-design-provoke`; `$explainerkit-design-random-entry`; `$explainerkit-design-connect-distant`; `$explainerkit-design-create-frames`; `$explainerkit-design-wander`, once for each of a, b; then keep-wanderings (a check: merge several wanderings, drop near-duplicates by word overlap, and keep the most fun, diverse ones.).
4. **Choose the story**: `$explainerkit-design-propose-seeds`, then rank-seeds (a check: order seeds by a weighted score that favours wonder and surprise, penalises textbook first examples, and keep the best few.), then `$explainerkit-design-choose-seed`.
5. **Research it**: independently of one another, `$explainerkit-design-find-people`; `$explainerkit-design-investigate`; `$explainerkit-design-find-parallels`.
6. **Deepen the story in a loop, alongside research** (repeat 2 times; each round's chosen question is the next round's focus): pick-lenses (a check: choose lens families for a reframing round, repeatably from a seed, never repeating one already used in the loop.), then `$explainerkit-design-deepen-frame`, then fresh-frames (a check: drop frames whose questions share most of their words with questions from earlier rounds, keeping at least one.), then `$explainerkit-design-read-around`, then `$explainerkit-design-choose-depth`.
7. **Ask what philosophy it touches**: `$explainerkit-design-map-debates`, then `$explainerkit-design-weigh-leap`, then check-philosophy (a check: check that an invited leap has a debate behind it, with a thought experiment and at least one reading with a URL.).
8. **Plan backward from the insight**: first `$explainerkit-design-work-backward`; then independently of one another, `$explainerkit-design-find-meaning`; `$explainerkit-design-find-image`.
9. **Try four tellings**: independently of one another, `$explainerkit-design-develop-telling`, once for each of mystery, chain, descent, experience; then check-tellings (a check: check each telling's structure: needs met in order, cues planted before recalled, loops closed, people present, and the size of the reveal.); then `$explainerkit-design-choose-telling`.
10. **Engineer the insight cascade**: `$explainerkit-design-engineer-cascade`, then check-cascade (a check: check the engineered telling: its structure, that every cue is planted before the reveal and recalled at it, how far apart, and in how many worlds.).
11. **Plan the hook and the refills**: `$explainerkit-design-research-hooks`, then `$explainerkit-design-engineer-hooks`.
12. **Draft and measure**: `$explainerkit-design-draft-script`, then script-measures (a check: count words, rhythm, questions, address, numbers, hedges, instructions and stock phrases in the narration.).
13. **Review three ways**: independently of one another, `$explainerkit-design-review-science`; `$explainerkit-design-review-learning`; `$explainerkit-design-review-story`.
14. **Revise and check the voice**: `$explainerkit-design-revise`, then script-measures (a check: count words, rhythm, questions, address, numbers, hedges, instructions and stock phrases in the narration.), then `$explainerkit-design-polish-voice`, only when the voice gate finds problems.
15. **Audit clarity and insight as each viewer** (repeat 2 times; each round's chosen question is the next round's focus): `$explainerkit-design-audit-insight`, then insight-measures (a check: verify the insight audit against the text: which planted cues literally appear before the aha and again at it, where the ending first leaks, and how surprise is spread.), then audience-insight (a check: compare the insight audits across personas: for whom the main eureka lands, where in the script, how many smaller eurekas each meets, and for whom the ending leaks early or never arrives.), then `$explainerkit-design-find-terms`, then term-measures (a check: check the listed terms against the text: where each is said, whether its picture comes before its first use, whether it returns bare after a long gap, and whether the eureka line depends on it.), then `$explainerkit-design-rewrite-plain`, only when a viewer got lost or a term is unexplained; replaces just those lines, then `$explainerkit-design-revise-for-insight`, only when the gate still finds problems; the script is then audited again, up to twice.
16. **Keep the viewer watching**: `$explainerkit-design-audit-attention`, then `$explainerkit-design-audit-attention-part`, instead of audit-attention when the script is longer than 4000 words; one part per chapter, then attention-measures (a check: keep the viewer's patience ledger over spoken time: spending counted in the text, earning taken from the audit's quotes found in the text, the balance curve, its low points and droughts, the opening and every section's first seconds, and the questions left open.), then `$explainerkit-design-revise-for-attention`, only when the attention gate finds problems; edits never touch the eureka or a cue, and the script is audited again.
17. **Look up how others showed it**: `$explainerkit-design-research-visuals`.
18. **Decide what each idea must show**: `$explainerkit-design-depict-ideas`, then `$explainerkit-design-plan-shots`, then time-shots (a check: time every shot from its cue in the narration, and check order, coverage, length and the medium.).
19. **Plan the visual structure**: `$explainerkit-design-design-structure`, then structure-measures (a check: measure the visual structure: shot lengths and cut rate, runs of one framing, whether every shot is in one sequence, intensity contrast between sequences, intensity where attention is low and the central image at both ends.).
20. **Look, feeling, motion and sound**: independently of one another, `$explainerkit-design-design-look`; look-measures (a check: check the look: valid HSLA colours, palette size, text contrast, accent use and value contrast at the peaks.); `$explainerkit-design-design-emotion`; emotion-measures (a check: check the emotional design: moves that carry no idea, decoration early, untied humour, character and metaphor coverage and a reflective close.); `$explainerkit-design-design-motion`; motion-measures (a check: check the motion plan: too many movers at once, long static shots, incongruent motion and a subject whose screen direction flips.); `$explainerkit-design-design-sound`, only when the medium has music or effects; sound-measures (a check: check the sound plan: music too loud under dense shots, effects not tied to a motion, no space before the reveal, and cues the medium cannot play.), only when the medium has music or effects.
21. **Check against the multimedia principles** (repeat 2 times; each round's chosen question is the next round's focus): multimedia-measures (a check: check the shot plan against the narration: redundant or long on-screen text, labels not said in their shot, too many elements, decoration in the opening, protected moments without a signal, long unpaused stretches and names used before they are shown.), then `$explainerkit-design-audit-multimedia`, then `$explainerkit-design-replan-shots`, only for shots whose words changed in a kept narration edit.
22. **Storyboard, animatic, style frames and images**: `$explainerkit-design-write-image-prompts`, only when the medium allows images.
23. **Name it**: `$explainerkit-design-name-it`.

## Writing rules

- Talk like a person, not a narrator: react, have an opinion, admit what seemed strange to you, allow yourself a joke. Say "I" about once a minute, for a reaction, a confession or an opinion.
- Vary the rhythm: some sentences of three or four words, and in every section at least one long one (25 words or more) that carries the listener through a whole thought. Never three short sentences in a row.
- Tell and show; do not give orders. Instructions ("Put a lens over...") only when the viewer is genuinely doing something at home.
- Name real people, places, objects and numbers. Abstract nouns are a last resort.
- Never use stock narration: "Have you ever wondered", "In this video", "Let's dive in", "fascinating", "mind-blowing", "journey", "delve", "buckle up", "stay tuned", "tapestry".
- Name things by what the viewer can picture, not by a label. Say "the faint hum from the power lines, whose pitch wobbles a little from minute to minute" rather than "a grid-related trace".
- Never coin a shorthand label for an idea and then use it as if it were a word ("the notch", "the trace", "the blind spot"). If a phrase must recur, it must first be a vivid picture and every return must still read plainly on its own.
- Introduce a technical word only when the piece needs it later, and only after the picture: show the thing, then give its name in one sentence. When it returns more than a few sections later, bring the picture back with it.
- At the eureka and in the ending, use only everyday words. The moment of understanding must not depend on remembering a term.
- Say a qualification aloud only when, without it, the audience would leave believing something false. Put every other qualification, condition or production warning in the notes field.
- Keep spoken hedges (can, may, might, ideal, typically, under conditions...) to about two per hundred words.
- When the story needs a measurement, give the published number and its source in the notes; do not say that nobody has measured it.
- List in cites the ids of the research claims each section relies on. Do not paste URLs into the narration; sources travel with the claim ids.
- Never leave a placeholder for a result ("[report the actual result]"). If the piece shows an experiment, say what it shows, using a published result.

## The result

Write the final script as an outline: the narration itself, split into lines so each claim and source sits beneath the sentence it supports. Every line starts with a tag in square brackets and its children are indented two spaces beneath it:

- [section] the section's id
  - [narration] one paragraph of what is spoken (long, flowing, written for the ear)
  - [visual] what the audience sees
  - [note] caveats and production details, never read aloud
  - [claim] a research claim the section relies on (confidence)
    - [source] title — URL

Run `node scripts/check-script.mjs <narration or outline file>` for the fixed checks: rhythm, hedges, choppy runs, instructions, the narrator, stock phrases, placeholders and spoken jargon.
