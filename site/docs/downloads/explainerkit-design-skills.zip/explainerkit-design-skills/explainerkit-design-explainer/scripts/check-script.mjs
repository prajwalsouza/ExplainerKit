#!/usr/bin/env node
// The fixed checks from explainerkit/design, for a script outside the library. Give it a text file of narration, or an
// outline.md, and it prints the counts and what the voice gate would ask for.
//   node scripts/check-script.mjs narration.txt
import { readFile } from 'node:fs/promises';
import { philosophyJargon, scriptStats, shortRuns } from './design/measures.js';

const GATE = {"maxHedgesPer100Words":2.2,"minSentenceSpread":7,"maxInstructionShare":0.08,"minNarratorPer100Words":1,"maxShortRuns":2};
const raw = await readFile(process.argv[2], 'utf8');
// From an outline, keep only the narration lines.
const narration = raw.includes('[narration]') ? raw.split('\n').filter((l) => l.includes('[narration]')).map((l) => l.replace(/^\s*- \[narration\] ?/, '')).join('\n\n') : raw;
const stats = scriptStats(narration), runs = shortRuns(narration), jargon = Object.keys(philosophyJargon(narration));
const problems = [];
if (stats.hedgesPer100Words > GATE.maxHedgesPer100Words) problems.push(`Too many spoken hedges: ${stats.hedgesPer100Words} per 100 words.`);
if (stats.sentenceSpread < GATE.minSentenceSpread) problems.push(`Flat rhythm: sentence-length spread ${stats.sentenceSpread}.`);
if (stats.narratorPer100Words < GATE.minNarratorPer100Words) problems.push('The narrator is almost absent.');
if (runs.length > GATE.maxShortRuns) problems.push(`${runs.length} runs of short sentences.`);
if (stats.sentences && stats.instructionSentences / stats.sentences > GATE.maxInstructionShare) problems.push('Too many sentences give the viewer orders.');
if (stats.stockPhrases.length) problems.push(`Stock phrases: ${stats.stockPhrases.join(', ')}.`);
if (stats.placeholders.length) problems.push('Placeholders instead of results.');
if (jargon.length) problems.push(`Philosophical jargon spoken aloud: ${jargon.join(', ')}.`);
console.log(JSON.stringify({ stats, choppyRuns: runs, jargon, problems }, null, 2));
