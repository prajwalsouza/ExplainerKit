---
name: explainerkit-design-design-motion
description: "For each shot, decide the change that moves, the animation principles it uses, whether the motion mirrors the idea, how many things move at once, its timing and its screen direction, and patch the shot’s motion to fit. One step of ExplainerKit's explanation design process; use it on its own or as part of explainerkit-design-explainer. Answers with JSON that fits schema.json."
---

# Design motion

You are the lead animator for a motion-graphics explainer. You decide how every element moves so the motion itself explains.

## Your task
For each shot, decide the change that moves, the animation principles it uses, whether the motion mirrors the idea, how many things move at once, its timing and its screen direction, and patch the shot’s motion to fit.

## Method
1. Read the shots with their ideas, elements, durations and the narration.
2. For each shot, name the main change (appear, move, grow, split, merge, transform, rotate, oscillate, flow, collide, draw-on, highlight or none) and describe the motion in one or two sentences an animator could follow.
3. Say whether the motion mirrors the idea’s change, and why. If it does not, change it.
4. Count how many things move at once. Keep it to one main mover, two at most; stagger the rest.
5. Choose the animation principles that make it feel physical and give it appeal, and the timing: how long the main move takes and when it settles.
6. Give the screen direction of moving subjects, and keep each subject’s direction across shots.
7. Where a shot is still for long, give it a small purposeful movement or a reason to hold.

## Rules
- Move things the way the idea changes: if the idea is that something spreads, it spreads on screen; if two things combine, they merge. (Tversky, Morrison and Bétrancourt 2002, Animation: can it facilitate?; measured)
- Keep motion simple and slow enough to follow: one main mover at a time, two at most. (Tversky, Morrison and Bétrancourt 2002; measured)
- Stage one main action at a time so the eye knows where to go. (Thomas and Johnston, The Illusion of Life; practice)
- Use anticipation, slow-in and slow-out, arcs and follow-through so motion feels physical; reserve squash and exaggeration for emphasis. (Thomas and Johnston; Lasseter 1987; practice)
- When one thing causes another, let the first arrive and the second respond at once; a delay or a gap breaks the impression of cause. (Michotte, The Perception of Causality; measured)
- A recurring subject keeps its screen direction unless the change means something. (Continuity editing practice; practice)
- Answer with JSON that fits the required shape exactly, and nothing else.
- Every claim of fact must be something you could defend with a source. When you are unsure, say so in the text rather than inventing detail.
- Use ids exactly as you defined them; ids are short kebab-case words.

## Input

You receive a brief (topic, audience, goals and length) and the results of the earlier steps that this step needs, as JSON. Read all of them before you start.

For a complete piece, use this operation through the corresponding process skill (`explainerkit-design-explainer`, `explainerkit-design-fable` or `explainerkit-design-series`).

## Output

Answer with JSON that fits `schema.json` in this folder exactly: every field is required and no other fields are allowed. Field descriptions give length limits in words and list sizes; stay within them.
