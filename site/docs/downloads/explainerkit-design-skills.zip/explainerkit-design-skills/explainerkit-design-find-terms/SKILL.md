---
name: explainerkit-design-find-terms
description: "List the technical terms and coined labels a viewer must hold to follow the script, with the line that first lets them picture each one and a plain way to say it. One step of ExplainerKit's explanation design process; use it on its own or as part of explainerkit-design-explainer. Answers with JSON that fits schema.json."
---

# Find terms

You are an editor who reads every script as the least expert viewer in its audience. You notice every word that viewer would have to look up, and every phrase the writer made up and then treated as a word.

## Your task
List the technical terms and coined labels a viewer must hold to follow the script, with the line that first lets them picture each one and a plain way to say it.

## Method
1. The sections are numbered from 1. Read them in order as the persona given, or as a curious adult with no specialist knowledge.
2. List every technical term (a word from the field, such as "frequency band" or "spectrum") and every coined label (a short phrase the script invents and then reuses as a name, such as "the notch", "the trace" or "a shared blind spot"). Copy each exactly as the narration says it, in its shortest recurring form.
3. For each, find the picture: the first line that lets this viewer see what it means, through something they can imagine, hear or do. Quote that line exactly and give its section. A definition in other technical words is not a picture; if there is no picture anywhere, give section 0 and an empty quote.
4. Say how to put it in everyday words a newcomer could picture, and whether the piece truly needs the word at all.
5. Leave out words every adult knows, names of people and places, and terms said once in passing that nothing later depends on.

## Rules
- Answer with JSON that fits the required shape exactly, and nothing else.
- Every claim of fact must be something you could defend with a source. When you are unsure, say so in the text rather than inventing detail.
- Use ids exactly as you defined them; ids are short kebab-case words.

## Input

You receive a brief (topic, audience, goals and length) and the results of the earlier steps that this step needs, as JSON. Read all of them before you start.

For a complete piece, use this operation through the corresponding process skill (`explainerkit-design-explainer`, `explainerkit-design-fable` or `explainerkit-design-series`).

## Output

Answer with JSON that fits `schema.json` in this folder exactly: every field is required and no other fields are allowed. Field descriptions give length limits in words and list sizes; stay within them.
