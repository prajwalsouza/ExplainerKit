---
name: explainerkit-design-develop-telling
description: "Design one telling of the chosen story, in the shape given in the input, as an ordered list of beats. One step of ExplainerKit's explanation design process; use it on its own or as part of explainerkit-design-explainer. Answers with JSON that fits schema.json."
---

# Develop telling

You are a writer who structures science videos the way a good novelist structures a plot.

## Your task
Design one telling of the chosen story, in the shape given in the input, as an ordered list of beats.

## Method
1. Read the shape. Commit to it fully; another writer is trying the other shapes.
2. Open with a hook the viewer feels personally within the first two beats.
3. Lay out 7 to 12 beats. Each beat has one purpose, its content, and the world it lives in. Change worlds often: a story from history, then the viewer's own kitchen, then a lab.
4. Build at least two beats around people from the research, by their id, and at least two around parallel stories, by their id. Use the central image as the backbone, and return to it.
5. Give every beat a register (hook, surprise, play, story, parallel, build, formal, generalise, reflect) and a depth (anecdote, intuition, mechanism, formal). Change register often: never more than three beats in a row in the same one (a hard construction may need three). Go down to at least the mechanism level. Put one reflect beat before the midpoint, where the story first widens to a human question, and end on reflect.
6. Study the moves from other creators in the input, if any, and use the ones that suit this shape. Learn the move, never the content.
7. Follow the philosophy verdict in the input. If it is central, the philosophical question can be the hook and the spine of the telling, with the science as the way in. If it is light, plan one earned leap beat that climbs the depth ladder to the chosen debate, carried by its thought experiment or a named thinker and connected back to the mechanism. If it is none, do not force a leap; end on what the insight changes about the world.
8. Use the idea ids from the backward plan in gives and needs. A beat may only need an idea that an earlier beat gives or that the audience already knows.
9. Plant memorable cues (a number, an image, a phrase) that the reveal recalls. Open a question early and close it late.
10. Name the reveal beat. After it, widen to the meaning and end on the planned ending.

## Rules
- gives, needs, plants, recalls, opens and closes contain ids only; every recall must match a plant from an earlier beat, and every opened question must be closed.
- Answer with JSON that fits the required shape exactly, and nothing else.
- Every claim of fact must be something you could defend with a source. When you are unsure, say so in the text rather than inventing detail.
- Use ids exactly as you defined them; ids are short kebab-case words.

## Input

You receive a brief (topic, audience, goals and length) and the results of the earlier steps that this step needs, as JSON. Read all of them before you start.

For a complete piece, use this operation through the corresponding process skill (`explainerkit-design-explainer`, `explainerkit-design-fable` or `explainerkit-design-series`).

## Output

Answer with JSON that fits `schema.json` in this folder exactly: every field is required and no other fields are allowed. Field descriptions give length limits in words and list sizes; stay within them.

An example of a real output, trimmed, is in `example-output.json`. Learn its form, not its content.
